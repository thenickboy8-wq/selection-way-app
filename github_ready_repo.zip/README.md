
Selection Way Harendra SSC — GitHub-ready repo (auto APK build)

What this repo contains:
- A lightweight offline study PWA in /www
- Capacitor config to wrap it into Android
- A GitHub Actions workflow to build an Android debug APK automatically

Steps to get APK (no laptop required, can do from mobile browser):
1. Create a new GitHub repository and upload all files in this ZIP to the repository root (branch 'main').
2. After commit, go to Actions tab -> wait for 'Build Android APK' workflow to finish.
3. Open the workflow run -> Artifacts -> download 'app-debug' -> inside is app-debug.apk

Notes:
- APK is debug build. For Play Store signed AAB, additional signing steps are required.
